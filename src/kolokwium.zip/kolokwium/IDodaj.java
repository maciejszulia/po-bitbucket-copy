package kolokwium;

public interface IDodaj {
    void DodajPolaczenie(String number, int czasP);

    void DodajSms(String number);

    void DodajInternet(int iloscMB);
}
