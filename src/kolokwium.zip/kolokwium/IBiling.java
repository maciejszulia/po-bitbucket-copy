package kolokwium;

import java.io.FileNotFoundException;

public interface IBiling {
    void ZapiszBiling() throws FileNotFoundException;
}
